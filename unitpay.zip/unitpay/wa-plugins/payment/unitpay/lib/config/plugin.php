<?php
return array(
    'name'        => 'Unitpay',
    'description' => 'Платежная система <a href="https://unitpay.ru" target="_blank">Unitpay</a>',
    'icon'        => 'img/unitpay16.png',
    'logo'        => 'img/unitpay.png',
    'vendor'      => 'webasyst',
    'version'     => '1.0.0',
    'locale'      => array('ru_RU',),
    'type'        => waPayment::TYPE_ONLINE,
);

<?php

return array(
	'unit_public_key' => array(
		'value'        => '',
		'title'        => 'PUBLIC KEY',
		'description'  => 'Скопируйте PUBLIC KEY со страницы проекта в системе Unitpay',
		'control_type' => 'input',
		'class'        => 'keys',
	),
	'unit_secret_key' => array(
		'value'        => '',
		'title'        => 'SECRET KEY',
		'description'  => 'Скопируйте SECRET KEY со страницы проекта в системе Unitpay',
		'control_type' => 'input',
		'class'        => 'keys',
	));
